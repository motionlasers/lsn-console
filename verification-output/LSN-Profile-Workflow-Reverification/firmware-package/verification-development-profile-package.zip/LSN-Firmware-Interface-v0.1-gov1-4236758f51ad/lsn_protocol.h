/*
 * AUTO-GENERATED FROM THE ACTIVE LSN DEVICE PROFILE. DO NOT EDIT.
 * Device Profile: 0.9.0-verification
 * Protocol: LSN v0.1
 * Console: 0.2.1
 * Package format: 1.0
 * Generated: 2026-08-22T00:44:04.345Z
 *
 * A missing #define is intentional: unresolved mappings cannot be used
 * accidentally as production values.
 */
#ifndef LSN_PROTOCOL_H
#define LSN_PROTOCOL_H

#include <stdint.h>
#include "lsn_protocol_types.h"

#define LSN_DEVICE_PROFILE_VERSION "0.9.0-verification"
#define LSN_PROTOCOL_VERSION "LSN v0.1"
#define LSN_HARDWARE_FAMILY "WT32-ETH01"

/* TBD: LSN_CIP_VENDOR_ID not defined; Vendor ID is not assigned in the Device Profile. */
/* TBD: LSN_CIP_DEVICE_TYPE not defined; Device Type is not assigned in the Device Profile. */
/* TBD: LSN_CIP_PRODUCT_CODE not defined; Product Code is not assigned in the Device Profile. */

/* Canonical field: TimerState */
#define LSN_TIMER_STATE_CIP_SERVICE "Get_Attribute_Single"
#define LSN_TIMER_STATE_CIP_CLASS UINT32_C(112)
#define LSN_TIMER_STATE_CIP_INSTANCE UINT32_C(1)
#define LSN_TIMER_STATE_CIP_ATTRIBUTE UINT32_C(4)
/* Assembly mapping (profile-defined JSON): {"inputAssembly":101,"outputAssembly":100} */

#endif /* LSN_PROTOCOL_H */
