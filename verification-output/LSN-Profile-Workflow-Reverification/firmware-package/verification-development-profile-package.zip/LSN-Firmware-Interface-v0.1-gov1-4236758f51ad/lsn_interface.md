# LSN Firmware Interface

Generated from Device Profile **0.9.0-verification** / Protocol **LSN v0.1**.

- Console version: 0.2.1
- Package format: 1.0
- Generated: 2026-08-22T00:44:04.345Z
- Target platform: WT32-ETH01

> Simulation validation is test-harness evidence only. It does not imply firmware implementation or physical validation.
>
> Unresolved mappings, enum values, string layouts, units, and byte/bit positions are intentionally marked **TBD**.

## TimerState

**Purpose:** Artificial verification-only timer state.

**Direction:** LSN → PC  
**Type:** uint32  
**Access:** READ  
**CIP Mapping:** Service=Get_Attribute_Single, Class=112, Instance=1, Attribute=4, Assembly={"inputAssembly":101,"outputAssembly":100}  
**Firmware Status:** IMPLEMENTED  
**Simulation Status:** VERIFIED  
**Units:** state  
**Byte / Bit:** 0 / 0

**Expected Firmware Behavior:** Return an artificial timer state for isolated verification.

**Expected Response:** Verification timer state.

**Notes:** NOT A PRODUCTION MAPPING.
