/*
 * AUTO-GENERATED FROM THE ACTIVE LSN DEVICE PROFILE. DO NOT EDIT.
 * Device Profile: 0.9.0-verification
 * Protocol: LSN v0.1
 * Console: 0.2.1
 * Package format: 1.0
 * Generated: 2026-08-22T00:44:04.345Z
 *
 * No enum values, string sizes, packing, or offsets are inferred.
 */
#ifndef LSN_PROTOCOL_TYPES_H
#define LSN_PROTOCOL_TYPES_H

#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* lsn_control_t is not declared because no field has a complete portable C representation.
 */

typedef struct {
    uint32_t timer_state; /* Canonical: TimerState */
} lsn_status_t;

/* All active field types have portable C representations. */

#ifdef __cplusplus
}
#endif

#endif /* LSN_PROTOCOL_TYPES_H */
