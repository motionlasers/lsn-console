LSN Firmware Integration Package
================================

Generated from:
- Device Profile: 0.1.0
- Protocol: LSN v0.1
- Console: 0.1.0
- Package format: 1.0
- Generated: 2026-08-14T08:56:43.345Z
- Target platform: WT32-ETH01
- Active interface fields: 15
- Resolved mappings: 0
- TBD mappings: 15

Purpose
-------
This package provides the canonical external LSN communications interface for
ESP32 firmware implementation. The complete machine-readable source profile is
included as lsn_protocol_profile.json.

Recommended workflow
--------------------
1. Review lsn_interface.md.
2. Use the generated C/C++ headers where their profile-defined types are complete.
3. Implement the logical fields in ESP32 firmware.
4. Assign real EtherNet/IP/CIP mappings and missing enum/string/layout definitions for TBD entries.
5. Return those decisions for entry into the LSN Device Profile, then regenerate this package.
6. Use LSN Engineering Console Hardware Mode to test the physical implementation.

Important boundaries
--------------------
- The Device Profile is the source of truth for the external LSN interface.
- This package defines the external interface; it is not firmware.
- The ESP32 programmer remains responsible for implementation details.
- Existing daughterboard GPIO mapping remains firmware-internal.
- The current daughterboard hardware is established and must not be redesigned as part of this interface work.
- This package does not dictate the internal state-machine architecture.
- Unresolved CIP mappings must be assigned by the firmware engineer.
- Generated headers never silently invent protocol, enum, packing, or identity values.
- Canonical Device Profile names remain authoritative even when local C field names use snake_case.
