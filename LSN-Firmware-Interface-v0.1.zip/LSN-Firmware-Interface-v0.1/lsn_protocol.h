/*
 * AUTO-GENERATED FROM THE ACTIVE LSN DEVICE PROFILE. DO NOT EDIT.
 * Device Profile: 0.1.0
 * Protocol: LSN v0.1
 * Console: 0.1.0
 * Package format: 1.0
 * Generated: 2026-08-14T09:25:59.253Z
 *
 * A missing #define is intentional: unresolved mappings cannot be used
 * accidentally as production values.
 */
#ifndef LSN_PROTOCOL_H
#define LSN_PROTOCOL_H

#include <stdint.h>
#include "lsn_protocol_types.h"

#define LSN_DEVICE_PROFILE_VERSION "0.1.0"
#define LSN_PROTOCOL_VERSION "LSN v0.1"
#define LSN_HARDWARE_FAMILY "WT32-ETH01"

/* TBD: LSN_CIP_VENDOR_ID not defined; Vendor ID is not assigned in the Device Profile. */
/* TBD: LSN_CIP_DEVICE_TYPE not defined; Device Type is not assigned in the Device Profile. */
/* TBD: LSN_CIP_PRODUCT_CODE not defined; Product Code is not assigned in the Device Profile. */

/* Canonical field: EmissionEnableRequest */
/* TBD: LSN_EMISSION_ENABLE_REQUEST_CIP_SERVICE not defined; CIP Service is not assigned. */
/* TBD: LSN_EMISSION_ENABLE_REQUEST_CIP_CLASS not defined; CIP Class is not assigned in the Device Profile. */
/* TBD: LSN_EMISSION_ENABLE_REQUEST_CIP_INSTANCE not defined; CIP Instance is not assigned in the Device Profile. */
/* TBD: LSN_EMISSION_ENABLE_REQUEST_CIP_ATTRIBUTE not defined; CIP Attribute is not assigned in the Device Profile. */
/* TBD: LSN_EMISSION_ENABLE_REQUEST_ASSEMBLY not defined; Assembly mapping is not assigned. */

/* Canonical field: FaultResetRequest */
/* TBD: LSN_FAULT_RESET_REQUEST_CIP_SERVICE not defined; CIP Service is not assigned. */
/* TBD: LSN_FAULT_RESET_REQUEST_CIP_CLASS not defined; CIP Class is not assigned in the Device Profile. */
/* TBD: LSN_FAULT_RESET_REQUEST_CIP_INSTANCE not defined; CIP Instance is not assigned in the Device Profile. */
/* TBD: LSN_FAULT_RESET_REQUEST_CIP_ATTRIBUTE not defined; CIP Attribute is not assigned in the Device Profile. */
/* TBD: LSN_FAULT_RESET_REQUEST_ASSEMBLY not defined; Assembly mapping is not assigned. */

/* Canonical field: Ready */
/* TBD: LSN_READY_CIP_SERVICE not defined; CIP Service is not assigned. */
/* TBD: LSN_READY_CIP_CLASS not defined; CIP Class is not assigned in the Device Profile. */
/* TBD: LSN_READY_CIP_INSTANCE not defined; CIP Instance is not assigned in the Device Profile. */
/* TBD: LSN_READY_CIP_ATTRIBUTE not defined; CIP Attribute is not assigned in the Device Profile. */
/* TBD: LSN_READY_ASSEMBLY not defined; Assembly mapping is not assigned. */

/* Canonical field: EmissionControlOutputActive */
/* TBD: LSN_EMISSION_CONTROL_OUTPUT_ACTIVE_CIP_SERVICE not defined; CIP Service is not assigned. */
/* TBD: LSN_EMISSION_CONTROL_OUTPUT_ACTIVE_CIP_CLASS not defined; CIP Class is not assigned in the Device Profile. */
/* TBD: LSN_EMISSION_CONTROL_OUTPUT_ACTIVE_CIP_INSTANCE not defined; CIP Instance is not assigned in the Device Profile. */
/* TBD: LSN_EMISSION_CONTROL_OUTPUT_ACTIVE_CIP_ATTRIBUTE not defined; CIP Attribute is not assigned in the Device Profile. */
/* TBD: LSN_EMISSION_CONTROL_OUTPUT_ACTIVE_ASSEMBLY not defined; Assembly mapping is not assigned. */

/* Canonical field: Faulted */
/* TBD: LSN_FAULTED_CIP_SERVICE not defined; CIP Service is not assigned. */
/* TBD: LSN_FAULTED_CIP_CLASS not defined; CIP Class is not assigned in the Device Profile. */
/* TBD: LSN_FAULTED_CIP_INSTANCE not defined; CIP Instance is not assigned in the Device Profile. */
/* TBD: LSN_FAULTED_CIP_ATTRIBUTE not defined; CIP Attribute is not assigned in the Device Profile. */
/* TBD: LSN_FAULTED_ASSEMBLY not defined; Assembly mapping is not assigned. */

/* Canonical field: FaultCode */
/* TBD: LSN_FAULT_CODE_CIP_SERVICE not defined; CIP Service is not assigned. */
/* TBD: LSN_FAULT_CODE_CIP_CLASS not defined; CIP Class is not assigned in the Device Profile. */
/* TBD: LSN_FAULT_CODE_CIP_INSTANCE not defined; CIP Instance is not assigned in the Device Profile. */
/* TBD: LSN_FAULT_CODE_CIP_ATTRIBUTE not defined; CIP Attribute is not assigned in the Device Profile. */
/* TBD: LSN_FAULT_CODE_ASSEMBLY not defined; Assembly mapping is not assigned. */

/* Canonical field: TimerState */
/* TBD: LSN_TIMER_STATE_CIP_SERVICE not defined; CIP Service is not assigned. */
/* TBD: LSN_TIMER_STATE_CIP_CLASS not defined; CIP Class is not assigned in the Device Profile. */
/* TBD: LSN_TIMER_STATE_CIP_INSTANCE not defined; CIP Instance is not assigned in the Device Profile. */
/* TBD: LSN_TIMER_STATE_CIP_ATTRIBUTE not defined; CIP Attribute is not assigned in the Device Profile. */
/* TBD: LSN_TIMER_STATE_ASSEMBLY not defined; Assembly mapping is not assigned. */

/* Canonical field: LifetimeEmissionTimeMs */
/* TBD: LSN_LIFETIME_EMISSION_TIME_MS_CIP_SERVICE not defined; CIP Service is not assigned. */
/* TBD: LSN_LIFETIME_EMISSION_TIME_MS_CIP_CLASS not defined; CIP Class is not assigned in the Device Profile. */
/* TBD: LSN_LIFETIME_EMISSION_TIME_MS_CIP_INSTANCE not defined; CIP Instance is not assigned in the Device Profile. */
/* TBD: LSN_LIFETIME_EMISSION_TIME_MS_CIP_ATTRIBUTE not defined; CIP Attribute is not assigned in the Device Profile. */
/* TBD: LSN_LIFETIME_EMISSION_TIME_MS_ASSEMBLY not defined; Assembly mapping is not assigned. */

/* Canonical field: EnableCount */
/* TBD: LSN_ENABLE_COUNT_CIP_SERVICE not defined; CIP Service is not assigned. */
/* TBD: LSN_ENABLE_COUNT_CIP_CLASS not defined; CIP Class is not assigned in the Device Profile. */
/* TBD: LSN_ENABLE_COUNT_CIP_INSTANCE not defined; CIP Instance is not assigned in the Device Profile. */
/* TBD: LSN_ENABLE_COUNT_CIP_ATTRIBUTE not defined; CIP Attribute is not assigned in the Device Profile. */
/* TBD: LSN_ENABLE_COUNT_ASSEMBLY not defined; Assembly mapping is not assigned. */

/* Canonical field: NetworkControlActive */
/* TBD: LSN_NETWORK_CONTROL_ACTIVE_CIP_SERVICE not defined; CIP Service is not assigned. */
/* TBD: LSN_NETWORK_CONTROL_ACTIVE_CIP_CLASS not defined; CIP Class is not assigned in the Device Profile. */
/* TBD: LSN_NETWORK_CONTROL_ACTIVE_CIP_INSTANCE not defined; CIP Instance is not assigned in the Device Profile. */
/* TBD: LSN_NETWORK_CONTROL_ACTIVE_CIP_ATTRIBUTE not defined; CIP Attribute is not assigned in the Device Profile. */
/* TBD: LSN_NETWORK_CONTROL_ACTIVE_ASSEMBLY not defined; Assembly mapping is not assigned. */

/* Canonical field: ProtocolVersion */
/* TBD: LSN_PROTOCOL_VERSION_CIP_SERVICE not defined; CIP Service is not assigned. */
/* TBD: LSN_PROTOCOL_VERSION_CIP_CLASS not defined; CIP Class is not assigned in the Device Profile. */
/* TBD: LSN_PROTOCOL_VERSION_CIP_INSTANCE not defined; CIP Instance is not assigned in the Device Profile. */
/* TBD: LSN_PROTOCOL_VERSION_CIP_ATTRIBUTE not defined; CIP Attribute is not assigned in the Device Profile. */
/* TBD: LSN_PROTOCOL_VERSION_ASSEMBLY not defined; Assembly mapping is not assigned. */

/* Canonical field: FirmwareVersion */
/* TBD: LSN_FIRMWARE_VERSION_CIP_SERVICE not defined; CIP Service is not assigned. */
/* TBD: LSN_FIRMWARE_VERSION_CIP_CLASS not defined; CIP Class is not assigned in the Device Profile. */
/* TBD: LSN_FIRMWARE_VERSION_CIP_INSTANCE not defined; CIP Instance is not assigned in the Device Profile. */
/* TBD: LSN_FIRMWARE_VERSION_CIP_ATTRIBUTE not defined; CIP Attribute is not assigned in the Device Profile. */
/* TBD: LSN_FIRMWARE_VERSION_ASSEMBLY not defined; Assembly mapping is not assigned. */

/* Canonical field: DeviceSerial */
/* TBD: LSN_DEVICE_SERIAL_CIP_SERVICE not defined; CIP Service is not assigned. */
/* TBD: LSN_DEVICE_SERIAL_CIP_CLASS not defined; CIP Class is not assigned in the Device Profile. */
/* TBD: LSN_DEVICE_SERIAL_CIP_INSTANCE not defined; CIP Instance is not assigned in the Device Profile. */
/* TBD: LSN_DEVICE_SERIAL_CIP_ATTRIBUTE not defined; CIP Attribute is not assigned in the Device Profile. */
/* TBD: LSN_DEVICE_SERIAL_ASSEMBLY not defined; Assembly mapping is not assigned. */

/* Canonical field: HardwareRevision */
/* TBD: LSN_HARDWARE_REVISION_CIP_SERVICE not defined; CIP Service is not assigned. */
/* TBD: LSN_HARDWARE_REVISION_CIP_CLASS not defined; CIP Class is not assigned in the Device Profile. */
/* TBD: LSN_HARDWARE_REVISION_CIP_INSTANCE not defined; CIP Instance is not assigned in the Device Profile. */
/* TBD: LSN_HARDWARE_REVISION_CIP_ATTRIBUTE not defined; CIP Attribute is not assigned in the Device Profile. */
/* TBD: LSN_HARDWARE_REVISION_ASSEMBLY not defined; Assembly mapping is not assigned. */

/* Canonical field: LastDisableReason */
/* TBD: LSN_LAST_DISABLE_REASON_CIP_SERVICE not defined; CIP Service is not assigned. */
/* TBD: LSN_LAST_DISABLE_REASON_CIP_CLASS not defined; CIP Class is not assigned in the Device Profile. */
/* TBD: LSN_LAST_DISABLE_REASON_CIP_INSTANCE not defined; CIP Instance is not assigned in the Device Profile. */
/* TBD: LSN_LAST_DISABLE_REASON_CIP_ATTRIBUTE not defined; CIP Attribute is not assigned in the Device Profile. */
/* TBD: LSN_LAST_DISABLE_REASON_ASSEMBLY not defined; Assembly mapping is not assigned. */

#endif /* LSN_PROTOCOL_H */
