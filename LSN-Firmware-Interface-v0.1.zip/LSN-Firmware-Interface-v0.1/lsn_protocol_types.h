/*
 * AUTO-GENERATED FROM THE ACTIVE LSN DEVICE PROFILE. DO NOT EDIT.
 * Device Profile: 0.1.0
 * Protocol: LSN v0.1
 * Console: 0.1.0
 * Package format: 1.0
 * Generated: 2026-08-14T08:56:43.345Z
 *
 * No enum values, string sizes, packing, or offsets are inferred.
 */
#ifndef LSN_PROTOCOL_TYPES_H
#define LSN_PROTOCOL_TYPES_H

#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    bool emission_enable_request; /* Canonical: EmissionEnableRequest */
    bool fault_reset_request; /* Canonical: FaultResetRequest */
} lsn_control_t;

typedef struct {
    bool ready; /* Canonical: Ready */
    bool emission_control_output_active; /* Canonical: EmissionControlOutputActive */
    bool faulted; /* Canonical: Faulted */
    uint16_t fault_code; /* Canonical: FaultCode */
    /* TBD: TimerState omitted; enum values and storage width are not assigned in the Device Profile. */
    uint64_t lifetime_emission_time_ms; /* Canonical: LifetimeEmissionTimeMs */
    uint64_t enable_count; /* Canonical: EnableCount */
    bool network_control_active; /* Canonical: NetworkControlActive */
    /* TBD: ProtocolVersion omitted; string encoding and maximum length are not assigned in the Device Profile. */
    /* TBD: FirmwareVersion omitted; string encoding and maximum length are not assigned in the Device Profile. */
    /* TBD: DeviceSerial omitted; string encoding and maximum length are not assigned in the Device Profile. */
    /* TBD: HardwareRevision omitted; string encoding and maximum length are not assigned in the Device Profile. */
    /* TBD: LastDisableReason omitted; enum values and storage width are not assigned in the Device Profile. */
} lsn_status_t;

/*
 * Unresolved logical types:
 * - TimerState: enum values and storage width are not assigned in the Device Profile.
 * - ProtocolVersion: string encoding and maximum length are not assigned in the Device Profile.
 * - FirmwareVersion: string encoding and maximum length are not assigned in the Device Profile.
 * - DeviceSerial: string encoding and maximum length are not assigned in the Device Profile.
 * - HardwareRevision: string encoding and maximum length are not assigned in the Device Profile.
 * - LastDisableReason: enum values and storage width are not assigned in the Device Profile.
 * Add the missing definitions to the Device Profile, then regenerate this package.
 */

#ifdef __cplusplus
}
#endif

#endif /* LSN_PROTOCOL_TYPES_H */
