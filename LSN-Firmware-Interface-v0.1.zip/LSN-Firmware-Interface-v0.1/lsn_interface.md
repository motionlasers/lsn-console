# LSN Firmware Interface

Generated from Device Profile **0.1.0** / Protocol **LSN v0.1**.

- Console version: 0.1.0
- Package format: 1.0
- Generated: 2026-08-14T08:56:43.345Z
- Target platform: WT32-ETH01

> Simulation validation is test-harness evidence only. It does not imply firmware implementation or physical validation.
>
> Unresolved mappings, enum values, string layouts, units, and byte/bit positions are intentionally marked **TBD**.

## EmissionEnableRequest

**Purpose:** Requested state is acknowledged; reported and hardware-control states remain independently readable.

**Direction:** PC → LSN  
**Type:** boolean  
**Access:** WRITE  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** VERIFIED  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Validate the request, evaluate all blocking conditions, and activate the control output only when permitted.

**Expected Response:** Requested state is acknowledged; reported and hardware-control states remain independently readable.

**Notes:** This is an emission-control request, not proof of optical emission.

## FaultResetRequest

**Purpose:** Faulted and FaultCode update to the resulting state.

**Direction:** PC → LSN  
**Type:** momentary-boolean  
**Access:** WRITE  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** TESTING  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Attempt to clear resettable faults without bypassing active blocking conditions.

**Expected Response:** Faulted and FaultCode update to the resulting state.

**Notes:** No behavior is assigned for non-resettable faults.

## Ready

**Purpose:** Boolean Ready state.

**Direction:** LSN → PC  
**Type:** boolean  
**Access:** READ  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** VERIFIED  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Report whether the LSN state machine is initialized and able to evaluate control requests.

**Expected Response:** Boolean Ready state.

**Notes:** Ready does not mean emission control is active.

## EmissionControlOutputActive

**Purpose:** Boolean hardware-control state.

**Direction:** LSN → PC  
**Type:** boolean  
**Access:** READ  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** VERIFIED  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Report the current state of the LSN emission-control hardware output.

**Expected Response:** Boolean hardware-control state.

**Notes:** Never infer optical emission from this value.

## Faulted

**Purpose:** Boolean fault state accompanied by FaultCode.

**Direction:** LSN → PC  
**Type:** boolean  
**Access:** READ  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** VERIFIED  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Report whether an active fault is present.

**Expected Response:** Boolean fault state accompanied by FaultCode.

**Notes:** None.

## FaultCode

**Purpose:** Unsigned fault value.

**Direction:** LSN → PC  
**Type:** uint16  
**Access:** READ  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** TESTING  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Report the profile-defined active fault code.

**Expected Response:** Unsigned fault value.

**Notes:** Final numerical definitions remain TBD.

## TimerState

**Purpose:** Profile-defined timer-state enum.

**Direction:** LSN → PC  
**Type:** enum  
**Access:** READ  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** VERIFIED  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Report NotCounting, Counting, Fault, or Unknown according to runtime accumulation.

**Expected Response:** Profile-defined timer-state enum.

**Notes:** Final numeric enum values remain TBD.

## LifetimeEmissionTimeMs

**Purpose:** Monotonic unsigned 64-bit milliseconds.

**Direction:** LSN → PC  
**Type:** uint64  
**Access:** READ  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** VERIFIED  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Persistently accumulate time only while the emission-control output is active.

**Expected Response:** Monotonic unsigned 64-bit milliseconds.

**Notes:** No normal remote reset command is permitted.

## EnableCount

**Purpose:** Monotonic lifetime enable count.

**Direction:** LSN → PC  
**Type:** uint64  
**Access:** READ  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** VERIFIED  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Persistently increment once per successful inactive-to-active control transition.

**Expected Response:** Monotonic lifetime enable count.

**Notes:** Read-only in normal operation.

## NetworkControlActive

**Purpose:** Boolean ownership state.

**Direction:** LSN → PC  
**Type:** boolean  
**Access:** READ  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** TESTING  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Report whether a network client currently owns control.

**Expected Response:** Boolean ownership state.

**Notes:** Ownership policy remains to be finalized.

## ProtocolVersion

**Purpose:** Version string comparable with the active Device Profile.

**Direction:** LSN → PC  
**Type:** string  
**Access:** READ  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** TESTING  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Expose the implemented logical protocol version.

**Expected Response:** Version string comparable with the active Device Profile.

**Notes:** None.

## FirmwareVersion

**Purpose:** Semantic version/build identifier.

**Direction:** LSN → PC  
**Type:** string  
**Access:** READ  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** TESTING  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Expose the running application firmware version.

**Expected Response:** Semantic version/build identifier.

**Notes:** None.

## DeviceSerial

**Purpose:** Device serial string.

**Direction:** LSN → PC  
**Type:** string  
**Access:** READ  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** NOT_TESTED  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Expose a stable unique device identity.

**Expected Response:** Device serial string.

**Notes:** None.

## HardwareRevision

**Purpose:** Hardware revision string.

**Direction:** LSN → PC  
**Type:** string  
**Access:** READ  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** NOT_TESTED  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Expose the hardware revision when available.

**Expected Response:** Hardware revision string.

**Notes:** None.

## LastDisableReason

**Purpose:** Profile-defined disable-reason enum.

**Direction:** LSN → PC  
**Type:** enum  
**Access:** READ  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** TESTING  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Record the reason for the latest active-to-inactive transition.

**Expected Response:** Profile-defined disable-reason enum.

**Notes:** Final numeric enum values remain TBD.
