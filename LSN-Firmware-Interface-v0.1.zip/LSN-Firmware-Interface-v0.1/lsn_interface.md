# LSN Firmware Interface

Generated from Device Profile **0.1.0** / Protocol **LSN v0.1**.

- Console version: 0.1.0
- Package format: 1.0
- Generated: 2026-08-14T09:25:59.253Z
- Target platform: WT32-ETH01

> Simulation validation is test-harness evidence only. It does not imply firmware implementation or physical validation.
>
> Unresolved mappings, enum values, string layouts, units, and byte/bit positions are intentionally marked **TBD**.

## EmissionEnableRequest

**Purpose:** Requests activation or deactivation of the LSN emission-control function.

**Direction:** PC → LSN  
**Type:** boolean  
**Access:** WRITE  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** VERIFIED  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Validate the request, evaluate all blocking conditions, and activate the control output only when permitted.

**Expected Response:** Requested state is acknowledged; reported and hardware-control states remain independently readable.

**Notes:** This is an emission-control request, not proof of optical emission.

## FaultResetRequest

**Purpose:** Momentary request to clear a resettable fault when its blocking condition is no longer present.

**Direction:** PC → LSN  
**Type:** momentary-boolean  
**Access:** WRITE  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** TESTING  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Attempt to clear resettable faults without bypassing active blocking conditions.

**Expected Response:** Faulted and FaultCode update to the resulting state.

**Notes:** No behavior is assigned for non-resettable faults.

## Ready

**Purpose:** Reports whether LSN is initialized and ready to evaluate control requests.

**Direction:** LSN → PC  
**Type:** boolean  
**Access:** READ  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** VERIFIED  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Report whether the LSN state machine is initialized and able to evaluate control requests.

**Expected Response:** Boolean Ready state.

**Notes:** Ready does not mean emission control is active.

## EmissionControlOutputActive

**Purpose:** Reports the current state of the LSN emission-control hardware output.

**Direction:** LSN → PC  
**Type:** boolean  
**Access:** READ  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** VERIFIED  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Report the current state of the LSN emission-control hardware output.

**Expected Response:** Boolean hardware-control state.

**Notes:** Never infer optical emission from this value.

## Faulted

**Purpose:** Reports whether LSN currently has an active fault.

**Direction:** LSN → PC  
**Type:** boolean  
**Access:** READ  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** VERIFIED  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Report whether an active fault is present.

**Expected Response:** Boolean fault state accompanied by FaultCode.

**Notes:** None.

## FaultCode

**Purpose:** Reports the active profile-defined fault code.

**Direction:** LSN → PC  
**Type:** uint16  
**Access:** READ  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** TESTING  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Report the profile-defined active fault code.

**Expected Response:** Unsigned fault value.

**Notes:** Final numerical definitions remain TBD.

## TimerState

**Purpose:** Reports whether the lifetime runtime counter is currently accumulating time.

**Direction:** LSN → PC  
**Type:** enum  
**Access:** READ  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** VERIFIED  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Report NotCounting, Counting, Fault, or Unknown according to runtime accumulation.

**Expected Response:** Profile-defined timer-state enum.

**Notes:** Final numeric enum values remain TBD.

## LifetimeEmissionTimeMs

**Purpose:** Accumulated lifetime emission-control active time in milliseconds.

**Direction:** LSN → PC  
**Type:** uint64  
**Access:** READ  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** VERIFIED  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Persistently accumulate time only while the emission-control output is active.

**Expected Response:** Monotonic unsigned 64-bit milliseconds.

**Notes:** No normal remote reset command is permitted.

## EnableCount

**Purpose:** Accumulated number of successful inactive-to-active emission-control transitions.

**Direction:** LSN → PC  
**Type:** uint64  
**Access:** READ  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** VERIFIED  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Persistently increment once per successful inactive-to-active control transition.

**Expected Response:** Monotonic lifetime enable count.

**Notes:** Read-only in normal operation.

## NetworkControlActive

**Purpose:** Reports whether a network client currently owns control of LSN.

**Direction:** LSN → PC  
**Type:** boolean  
**Access:** READ  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** TESTING  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Report whether a network client currently owns control.

**Expected Response:** Boolean ownership state.

**Notes:** Ownership policy remains to be finalized.

## ProtocolVersion

**Purpose:** Reports the implemented LSN communications-interface version.

**Direction:** LSN → PC  
**Type:** string  
**Access:** READ  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** TESTING  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Expose the implemented logical protocol version.

**Expected Response:** Version string comparable with the active Device Profile.

**Notes:** None.

## FirmwareVersion

**Purpose:** Reports the currently running LSN application firmware version.

**Direction:** LSN → PC  
**Type:** string  
**Access:** READ  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** TESTING  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Expose the running application firmware version.

**Expected Response:** Semantic version/build identifier.

**Notes:** None.

## DeviceSerial

**Purpose:** Canonical logical device-identity field. Final representation and mapping remain TBD pending the firmware engineer's CIP Identity Object implementation.

**Direction:** LSN → PC  
**Type:** string  
**Access:** READ  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** NOT_TESTED  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Expose a stable unique device identity.

**Expected Response:** Device serial string.

**Notes:** None.

## HardwareRevision

**Purpose:** Reports the LSN hardware revision when available.

**Direction:** LSN → PC  
**Type:** string  
**Access:** READ  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** NOT_TESTED  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Expose the hardware revision when available.

**Expected Response:** Hardware revision string.

**Notes:** None.

## LastDisableReason

**Purpose:** Reports the reason for the most recent transition from active to inactive emission control.

**Direction:** LSN → PC  
**Type:** enum  
**Access:** READ  
**CIP Mapping:** Service=TBD, Class=TBD, Instance=TBD, Attribute=TBD, Assembly=TBD  
**Firmware Status:** TBD  
**Simulation Status:** TESTING  
**Units:** TBD  
**Byte / Bit:** TBD / TBD

**Expected Firmware Behavior:** Record the reason for the latest active-to-inactive transition.

**Expected Response:** Profile-defined disable-reason enum.

**Notes:** Final numeric enum values remain TBD.
